<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model {

public function loginaata($email,$pass)
{ echo "<pre>";
//$this->load->library("database");
$this->load->database();
 	//$x=$this->db->where('email',$email);
	//$y=$this->db->where('password',md5($pass));
	$query=$this->db->get("users");
if($query->num_rows()>0)
{
	
$row=$query->row();
//return array();

/*$userdata = array(
'user_id'  => $row->id,
'username'  => $row->username,
'email'    => $row->email,
);*/
//$this->session->set_userdata($userdata);
return $row;
}
return false;

	
	
	
	}
	
}