<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends CI_Controller {
public function __construct()
{
parent::__construct();
$this->load->library('form_validation');
$this->load->model('user_model');
}
public function index()
{
if(($this->session->userdata('user_id')!=""))
{
redirect(site_url('home'));
}
else
{
$this->load->view("register_view");
}
}
public function login()
{
$rules = array(array('field'=>'l_email','label'=>'Email','rules'=>'required|valid_email'),
array('field'=>'l_pass','label'=>'Password','rules'=>'required'));
$this->form_validation->set_rules($rules);
if($this->form_validation->run() == FALSE)
{
$this->index();
}
else
{
$auth=$this->user_model->login($this->input->post('l_email'),$this->input->post('l_pass'));
if($auth)
{
redirect(site_url('home'));
}
else
{
$this->index();
}
}
}public function register()
{
$this->load->view('register_view');//loads the register_view.php file in views folder
}
public function do_register()
{
$rules = array(
array('field'=>'username','label'=>'User Name','rules'=>'trim|required|min_length[4]|max_length[12]'),
array('field'=>'email','label'=>'Email','rules'=>'trim|required|valid_email|is_unique[users.email]'),
array('field'=>'password','label'=>'Password','rules'=>'trim|required|min_length[6]'),
array('field'=>'gender','label'=>'Gender','rules'=>'required')
);
$this->form_validation->set_rules($rules);
if($this->form_validation->run() == FALSE)
{
$this->load->view('register_view');
}
else
{
$this->user_model->register_user();
$this->load->view('success');
}
}
public function logout()
{
$this->session->sess_destroy();
redirect(site_url());
}


public function multiupload()
{
$filename="movieposter_".time();
$config['upload_path'] = 'uploads/';
$config['allowed_types'] = 'gif|jpg|png';
$config['max_size']    = '10024';
$config['max_width']  = '20480';
$config['max_height']  = '8000';
$config['file_name']= $filename;
$this->load->library('upload', $config);
if ( ! $this->upload->do_upload())
{
$error = array('error' => $this->upload->display_errors());
$this->load->view('login_view', $error);
}
else
{
$data=$this->upload->data();
print_r($data);exit;

$file=array(
'image1'=>$filename.$data['file_ext'],
'image2'=>$filename.$data['file_ext'],
'image3'=>$filename.$data['file_ext']
);
$this->user_model->insertmultiimages($file);
redirect(site_url('login_view'));
}

}


}