<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function index()
	{
		
		$this->load->view('login_view');
	}
	
	public function logins()
	{
		$this->load->model('login_model');
		//print_r($_POST); exit;
	 	$uid=$this->input->post('email');
		$pwd=$this->input->post("pwd"); 

        $loginres['records']=$this->login_model->loginaata($uid,$pwd);	
		
		$this->lod->view('login_view',$loginres);
		//print_r($loginres); exit;
		}
}
