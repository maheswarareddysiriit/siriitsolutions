<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.page {
    width:960px;
    margin:0 auto;
}
#response { padding: 10px; }
.success { background:#CCFFCC; }
.error { background: #FF6666; }
.loading { background: #FFFFCC; }
iframe {
    width:0px;
    height:0px;
    border:none;
    position:absolute;
    left:-9999px;
}
</style>
</head>

<body>
<div class="page">
    <h1>Sample form</h1>
    <div id="responsess"><?php if(isset($error)){ echo $error; } ?></div>
    <form action="<?php echo site_url(); ?>user/multiupload" method="post" enctype="multipart/form-data">
        <div>
            <input type="file" name="testfile1"><br><br><br>
            <input type="file" name="testfile2"><br><br><br>
            <input type="file" name="testfile3"><br><br><br>
            <input type="submit">
        </div>
    </form>
</div>
</form>
</body>
</html>